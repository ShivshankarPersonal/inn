import React from 'react'
import {connect} from 'react-redux'
import {spendRange} from '../actions'
import {Grid, Row, Col} from 'react-bootstrap'

let MarketingChannel = () => {

  return (
  <div>
    <Grid>
      <Row className="show-grid">
        <Col md={12}>
          <h2>MARKETING CHANNEL MIX</h2>
        </Col>
      </Row>
    </Grid>
  </div>


)


}

export default MarketingChannel
