import React from 'react'
import Footer from './Footer'
import AddTodo from '../containers/AddTodo'
import VisibleTodoList from '../containers/VisibleTodoList'
import MarketingChannel from '../containers/MarketingChannel'

const App = () => (
  <div>
    <MarketingChannel/>
    {/*<AddTodo />*/}
    {/*<VisibleTodoList />*/}
    {/*<Footer />*/}
  </div>
)

export default App
